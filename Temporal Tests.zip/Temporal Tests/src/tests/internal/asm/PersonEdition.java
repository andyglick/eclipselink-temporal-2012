package tests.internal.asm;

import model.Person;

public interface PersonEdition extends Person {

}
